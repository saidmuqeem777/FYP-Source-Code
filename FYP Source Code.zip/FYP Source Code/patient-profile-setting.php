<?php
/**
 * Created by PhpStorm.
 * User: Said Muqeem Halimi
 * Date: 08-Jul-20
 * Time: 8:03 PM
 */
    require_once ("database-connection.php");
    session_start();
if (!isset($_COOKIE['username'])){
    header("location:index.php?haveaccount");
    return;
}if(isset($_COOKIE['username'])){
    $_SESSION['username']=$_COOKIE['username'];
}
    $patientID=null;
    $patientDetails=null;


    $username=$_SESSION['username'];


?>

<?php
    $user_id=$con->query("select user_id from users where user_username='$username'")->fetch_array()['user_id'];

    $patientDetails=$con->query("select * from users where user_username='$username'")->fetch_array();
    $patientImage=$con->query("select * from pictures where user_id='$user_id'")->fetch_array()['file_name'];



    if (isset($_REQUEST['save'])){



        if(file_exists($_FILES['image']['tmp_name']) || is_uploaded_file($_FILES['image']['tmp_name'])) {

            $image_name=$_FILES['image']['name'];

            $file_extension=substr($image_name,strlen($image_name)-3,3);
            $tmp_file_at_server = $_FILES['image']['tmp_name'];

            $file_name_at_server = time();

            $new_file_path = "./assets/img/patients".'/'.$file_name_at_server.'.'.$file_extension;

            if (is_uploaded_file($tmp_file_at_server)) {
                move_uploaded_file($tmp_file_at_server, $new_file_path);
            }

            $image_name=$file_name_at_server.'.'.$file_extension;

            mysqli_query($con,"delete from pictures where user_id='$user_id'");
            mysqli_query($con,"insert into pictures values ('','$image_name','$user_id')");

        }
        if ((isset($_REQUEST['name'])) && (isset($_REQUEST['email'])) && (isset($_REQUEST['contact'])) && (isset($_REQUEST['address']))){
            $name=$_REQUEST['name'];

            $contact=$_REQUEST['contact'];
            $address=$_REQUEST['address'];

            mysqli_query($con,"update users set user_name='$name',user_address='$address',user_contact='$contact' where user_id='$user_id'");


        }

        header("location:patient-profile-setting.php");
        return;



    }

?>
<html>
<head>
    <meta charset="utf-8">
    <title>Patient Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="assets/plugins/select2/css/select2.min.css">

    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>

<!--Main Wrapper-->
    <div class="main-wrapper">
        <!--Header Part-->
        <header class="header">
            <nav class="navbar navbar-expand-lg header-nav">
                <!---Logo-->
                <div class="navbar-header">
                    <a href="index.php" class="navbar-brand logo"><img src="assets/img/log.png" class="img-fluid" alt="Logo"></a>
                </div>
                <ul class="nav header-navbar-rht">
                    <!-- User Menu -->
                    <li class="nav-item dropdown has-arrow logged-item">
                        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
								<span class="user-img">
									<img class="rounded-circle" src="assets/img/patients/<?=$patientImage?>" width="31" alt="<?= $patientDetails['user_name'] ?>">
								</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <div class="user-header">
                                <div class="avatar avatar-sm">
                                    <img src="assets/img/patients/<?=$patientImage?>" alt="Patient Image" class="avatar-img rounded-circle">
                                </div>
                                <div class="user-text">
                                    <h6><?=$patientDetails['user_name']?></h6>
                                    <p class="text-muted mb-0">Patient</p>
                                </div>
                            </div>
                            <a class="dropdown-item" href="patient-dashboard.php">Dashboard</a>
                            <a class="dropdown-item" href="patient-profile-setting.php">Profile Settings</a>
                            <a class="dropdown-item" href="index.php">Logout</a>
                        </div>
                    </li>
                    <!-- /User Menu -->

                </ul>
            </nav>


        </header>
        <!--/Header-->

        <!--Page Content-->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- Profile Sidebar -->
                    <div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
                        <div class="profile-sidebar">
                            <div class="widget-profile pro-widget-content">
                                <div class="profile-info-widget">
                                    <a href="#" class="booking-doc-img">
                                        <img src="assets/img/patients/<?=$patientImage?>" alt="User Image">
                                    </a>
                                    <div class="profile-det-info">
                                        <h3><?=$patientDetails['user_name']?></h3>
                                        <div class="patient-details">

                                            <h5 class="mb-0"><i class="fas fa-map-marker-alt"></i> <?=$patientDetails['user_address']?>, Afghanistan</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="dashboard-widget">
                                <nav class="dashboard-menu">
                                    <ul>
                                        <li>
                                            <a href="patient-dashboard.php">
                                                <i class="fas fa-columns"></i>
                                                <span>Dashboard</span>
                                            </a>
                                        </li>
                                        <li id="patFavourites">
                                            <a href="#" onclick="patientFavourites();">
                                                <i class="fas fa-bookmark"></i>
                                                <span>Favourites</span>
                                            </a>
                                        </li>

                                        <li class="active">
                                            <a href="patient-profile-setting.php">
                                                <i class="fas fa-user-cog"></i>
                                                <span>Profile Settings</span>
                                            </a>
                                        </li>
                                        <li id="patientPassword">
                                            <a href="patient-change-password.php">
                                                <i class="fas fa-lock"></i>
                                                <span>Change Password</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="patient-delete-account.php">
                                                <i class="fas fa-trash-alt"></i>
                                                <span>Delete Account</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="index.php">
                                                <i class="fas fa-sign-out-alt"></i>
                                                <span>Logout</span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>

                        </div>
                    </div>
                    <!-- / Profile Sidebar -->
                    <!--Profile Setting-->
                    <div class="col-md-7 col-lg-8 col-xl-9">
                        <div class="card">
                            <div class="card-body">

                                <!-- Profile Settings Form -->
                                <form action="patient-profile-setting.php" method="POST" enctype="multipart/form-data">
                                    <div class="row form-row">
                                        <div class="col-12 col-md-12">
                                            <div class="form-group">
                                                <div class="change-avatar">
                                                    <div class="profile-img">
                                                        <img src="assets/img/patients/<?=$patientImage?>" alt="Patient Image">
                                                    </div>
                                                    <div class="upload-img">
                                                        <div class="change-photo-btn">
                                                            <span><i class="fa fa-upload"></i> Upload Photo</span>
                                                            <input type="file" name="image"  accept="image/*" class="upload">
                                                        </div>
                                                        <small class="form-text text-muted">Allowed JPG, GIF or PNG. Max size of 2MB</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12  col-md-6">
                                            <div class="form-group">
                                                <label>Full Name</label>
                                                <input type="text" name="name" value="<?=$patientDetails['user_name']?>" class="form-control" required>
                                            </div>
                                        </div>


                                        <div class="col-12 col-md-6">
                                            <div class="form-group">
                                                <label>Email ID</label>
                                                <input type="email" name="email" value="<?=$patientDetails['user_username']?>" class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <div class="form-group">
                                                <label>Mobile</label>
                                                <input type="text" name="contact" value="<?=$patientDetails['user_contact']?>" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <div class="form-group">
                                                <label>Address</label>
                                                <input type="text" name="address" value="<?=$patientDetails['user_address']?>" class="form-control" required>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="float-right">
                                        <button type="submit" name="save" class="btn btn-primary submit-btn">Save Changes</button>
                                    </div>
                                </form>
                                <!-- /Profile Settings Form -->

                            </div>

                        </div>

                    </div>


                    <!--/Profile Setting-->



                </div>
            </div>
        </div>
        <!--/Page Content-->



    </div>
<!--/Main Wrapper-->

<!-- jQuery -->
<script src="assets/js/jquery.min.js"></script>

<!-- Bootstrap Core JS -->
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>



<!-- Select2 JS -->
<script src="assets/plugins/select2/js/select2.min.js"></script>

<!-- Datetimepicker JS -->
<script src="assets/js/moment.min.js"></script>
<script src="assets/js/bootstrap-datetimepicker.min.js"></script>





<!-- Custom JS -->
<script src="assets/js/script.js"></script>
<script src="assets/js/script2.js"></script>
</body>
</html>

