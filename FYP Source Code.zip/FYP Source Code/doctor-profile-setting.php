<?php
/**
 * Created by PhpStorm.
 * User: Said Muqeem Halimi
 * Date: 17-May-20
 * Time: 3:51 PM
 */

    require_once ("database-connection.php");
    session_start();
/*   Doctor Information       */
    $doctorRecordRow=null;
    $pro_des=null;
    $doc_id=null;
    $profileSettingSuccess=false;
    $doc_clinics=null;
    $doc_education=null;
    $doc_experience=null;
    $doc_image=null;






if (!isset($_COOKIE['username'])){
    header("location:login.php");
    return;
}if(isset($_COOKIE['username'])){
    $_SESSION['username']=$_COOKIE['username'];
}if (isset($_SESSION['username'])){


        $username=$_SESSION['username'];
        $doctorRecord=$con->query("select doc_id from users where user_username='$username'");
        $doctorRecordRow=$doctorRecord->fetch_array();
        $doc_id=$doctorRecordRow['doc_id'];

        $doctorRecord=$con->query("select * from doctor where doc_id='$doc_id'");
        $u_id=$con->query("select user_id from users where user_username='$username'")->fetch_array()['user_id'];
        $pro_des=$con->query("select * from doctorprofile where user_id='$u_id'")->fetch_array();
        $proID=$pro_des['profile_id'];
        $doc_clinics=$con->query("select * from doctorclinics where profile_id='$proID'");
        $doc_education=$con->query("select * from doctoreducation where profile_id='$proID'");
        $doc_experience=$con->query("select * from doctorexpierence where profile_id='$proID'");
        $doc_image=$con->query("select * from pictures where user_id='$u_id'")->fetch_array()['file_name'];



        $doctorRecordRow=$doctorRecord->fetch_array();



}
    if (isset($_REQUEST['upload'])){
        $username=$_SESSION['username'];
        $u_id=$con->query("select user_id from users where user_username='$username'")->fetch_array()['user_id'];


        $image_name=$_FILES['doc_image']['name'];
        $target_dir="./assets/img/doctors/";

        $file_extension=substr($image_name,strlen($image_name)-3,3);
        $tmp_file_at_server = $_FILES['doc_image']['tmp_name'];

        $file_name_at_server = time();

        $new_file_path = "./assets/img/doctors".'/'.$file_name_at_server.'.'.$file_extension;
        if (is_uploaded_file($tmp_file_at_server)) {
            move_uploaded_file($tmp_file_at_server, $new_file_path);

        }
        $image=$file_name_at_server.'.'.$file_extension;

        $selectImage=$con->query("select file_name from pictures where user_id='$u_id'")->fetch_array()['file_name'];


        mysqli_query($con,"delete from pictures where user_id='$u_id'");


        mysqli_query($con,"insert into pictures values ('','$image','$u_id')");








    }
?>


<?php
    if (isset($_REQUEST['save'])){
        $biography=$_REQUEST['biography'];
    $clinicName=$_REQUEST['clinicName'];
    $clinicAddress=$_REQUEST['clinicAddress'];
    $addressLine=$_REQUEST['addressLine'];
    $city=$_REQUEST['city'];
    $province=$_REQUEST['province'];
    $fees=$_REQUEST['fees'];
    $services=$_REQUEST['services'];
    $specializations=$_REQUEST['specializations'];

    $degree1=$_REQUEST['degree1'];
    $degree2=$_REQUEST['degree2'];
    $degree3=$_REQUEST['degree3'];
    $degree4=$_REQUEST['degree4'];

    $college1=$_REQUEST['college1'];
    $college2=$_REQUEST['college2'];
    $college3=$_REQUEST['college3'];
    $college4=$_REQUEST['college4'];

    $year1=$_REQUEST['yearofcompletion1'];
    $year2=$_REQUEST['yearofcompletion2'];
    $year3=$_REQUEST['yearofcompletion3'];
    $year4=$_REQUEST['yearofcompletion4'];

        $username=$_SESSION['username'];
        $profile_id=$pro_des['profile_id'];
        $user_id=$pro_des['user_id'];

        $selectDoctorProfile=$con->query("select * from doctorprofile where profile_id='$profile_id'");
        $counterRecord=mysqli_num_rows($selectDoctorProfile);


    if ($counterRecord==0){
        mysqli_query($con,"insert into doctorprofile values ('','$biography','$addressLine','$city','$province','$fees','$services','$specializations','$user_id')");
        header("location:doctor-profile-setting.php");
        return;
    }else{

        mysqli_query($con,"update doctorprofile set profile_biography='$biography',contact='$addressLine',profile_city='$city',profile_province='$province',profile_fees='$fees',profile_services='$services',profile_specilizations='$specializations',user_id='$user_id' where profile_id='$profile_id'");


        header("location:doctor-profile-setting.php");
        return;

    }

    }elseif ((isset($_REQUEST['saveme']))){

        $biography=$_REQUEST['biography'];
        $clinicName=$_REQUEST['clinicName'];
        $clinicAddress=$_REQUEST['clinicAddress'];
        $addressLine=$_REQUEST['addressLine'];
        $city=$_REQUEST['city'];
        $province=$_REQUEST['province'];
        $fees=$_REQUEST['fees'];
        $services=$_REQUEST['services'];
        $specializations=$_REQUEST['specializations'];

        $username=$_SESSION['username'];
        $profile_id=$pro_des['profile_id'];
        $user_id=$pro_des['user_id'];

        $selectDoctorProfile=$con->query("select * from doctorprofile where profile_id='$profile_id'");
        $counterRecord=mysqli_num_rows($selectDoctorProfile);

        if ($counterRecord==0){
            mysqli_query($con,"insert into doctorprofile values ('','$biography','$addressLine','$city','$province','$fees','$services','$specializations','$user_id')");
            header("location:doctor-profile-setting.php");
            return;
        }else{
            mysqli_query($con,"update doctorprofile set profile_biography='$biography',contact='$addressLine',profile_city='$city',profile_province='$province',profile_fees='$fees',profile_services='$services',profile_specilizations='$specializations',user_id='$user_id' where profile_id='$profile_id'");
            header("location:doctor-profile-setting.php");
            return;
        }

    }elseif (isset($_REQUEST['saveclinicdetails'])){

        if (isset($_REQUEST['firstClinic'])){
            $clinicName=$_REQUEST['cliName'];
            $clinicAddress=$_REQUEST['cliAddress'];

            $profile_id=$pro_des['profile_id'];

            $con->query("insert into doctorclinics values ('','$clinicName','$clinicAddress','$profile_id')");

        }

        if (isset($_REQUEST['clinicID'][0])){
            $docClinicId=$_REQUEST['clinicID'][0];
           $clinicName=$_REQUEST['clinicName'][0];
           $clinicAddress=$_REQUEST['clinicAddress'][0];
           $profileID=$_REQUEST['profileID'];

           $clinicRow=$con->query("select * from doctorclinics where doc_clinic_id='$docClinicId'");
           $counterClinicRecord=mysqli_num_rows($clinicRow);

           if ($counterClinicRecord==0){
               mysqli_query($con,"insert into doctorclinics values ('','$docClinicId','$clinicName','$clinicAddress','$profileID')");

           }else{
               mysqli_query($con,"update doctorclinics set clinic_name='$clinicName',clinic_address='$clinicAddress' where doc_clinic_id='$docClinicId'");

           }
        }
        if (isset($_REQUEST['clinicID'][1])){
            $docClinicId=$_REQUEST['clinicID'][1];
            $clinicName=$_REQUEST['clinicName'][1];
            $clinicAddress=$_REQUEST['clinicAddress'][1];
            $profileID=$_REQUEST['profileID'];

            $clinicRow=$con->query("select * from doctorclinics where doc_clinic_id='$docClinicId'");
            $counterClinicRecord=mysqli_num_rows($clinicRow);

            if ($counterClinicRecord==0){
                mysqli_query($con,"insert into doctorclinics values ('','$docClinicId','$clinicName','$clinicAddress','$profileID')");

            }else{
                mysqli_query($con,"update doctorclinics set clinic_name='$clinicName',clinic_address='$clinicAddress' where doc_clinic_id='$docClinicId'");

            }
        }
        if (isset($_REQUEST['clinicID'][2])){
            $docClinicId=$_REQUEST['clinicID'][2];
            $clinicName=$_REQUEST['clinicName'][2];
            $clinicAddress=$_REQUEST['clinicAddress'][2];
            $profileID=$_REQUEST['profileID'];

            $clinicRow=$con->query("select * from doctorclinics where doc_clinic_id='$docClinicId'");
            $counterClinicRecord=mysqli_num_rows($clinicRow);

            if ($counterClinicRecord==0){
                mysqli_query($con,"insert into doctorclinics values ('','$docClinicId','$clinicName','$clinicAddress','$profileID')");

            }else{
                mysqli_query($con,"update doctorclinics set clinic_name='$clinicName',clinic_address='$clinicAddress' where doc_clinic_id='$docClinicId'");

            }
        }
        if (isset($_REQUEST['clinicID'][3])){
            $docClinicId=$_REQUEST['clinicID'][3];
            $clinicName=$_REQUEST['clinicName'][3];
            $clinicAddress=$_REQUEST['clinicAddress'][3];
            $profileID=$_REQUEST['profileID'];

            $clinicRow=$con->query("select * from doctorclinics where doc_clinic_id='$docClinicId'");
            $counterClinicRecord=mysqli_num_rows($clinicRow);

            if ($counterClinicRecord==0){
                mysqli_query($con,"insert into doctorclinics values ('','$docClinicId','$clinicName','$clinicAddress','$profileID')");

            }else{
                mysqli_query($con,"update doctorclinics set clinic_name='$clinicName',clinic_address='$clinicAddress' where doc_clinic_id='$docClinicId'");

            }
        }
        if (isset($_REQUEST['newclinic'])){
            $profileID=$_REQUEST['profileID'];

            $clinicNames=$_REQUEST['newclinicName'];
            $clinicAddress=$_REQUEST['newclinicAddress'];

            for($i=0;$i<sizeof($clinicNames);$i++){
                mysqli_query($con,"insert into doctorclinics values ('','$clinicNames[$i]','$clinicAddress[$i]','$profileID')");
            }


        }


        header("location:doctor-profile-setting.php");
        return;

    }elseif (isset($_REQUEST['savedoceducation'])){
        $profile_id=$pro_des['profile_id'];

        if (isset($_REQUEST['newEducation'])){
            $degree=$_REQUEST['docDegree'];
            $college=$_REQUEST['docCollege'];
            $completion=$_REQUEST['docCompletion'];
            $profile_id=$pro_des['profile_id'];

            $con->query("insert into doctoreducation values ('','$degree','$college','$completion','$profile_id')");

        }
        if (isset($_REQUEST['edu_id'])){

            $edu_id=$_REQUEST['edu_id'];
            $docDegree=$_REQUEST['doctorDegree'];
            $docCollege=$_REQUEST['doctorCollege'];
            $docCompletion=$_REQUEST['doctorCompletion'];


            for ($i=0;$i<sizeof($edu_id);$i++){
                $doc_edu_id=$edu_id[$i];
                $degree=$docDegree[$i];
                $college=$docCollege[$i];
                $completion=$docCompletion[$i];

                $con->query("update doctoreducation set degree='$degree',college='$college',yearofcompletion='$completion' where doc_edu_id='$doc_edu_id'");

            }
        }
        if (isset($_REQUEST['addNewDegrees'])){

            $degree=$_REQUEST['degree'];
            $college=$_REQUEST['college'];
            $completion=$_REQUEST['completion'];

            for($i=0;$i<sizeof($degree);$i++){
                mysqli_query($con,"insert into doctoreducation values ('','$degree[$i]','$college[$i]','$completion[$i]','$profile_id')");
            }





        }


        header("location:doctor-profile-setting.php");
        return;
    }elseif (isset($_REQUEST['savedocexperience'])){
        $profile_id=$pro_des['profile_id'];
       if (isset($_REQUEST['firstExperience'])){
         $hosName=$_REQUEST['hosName'];
         $startDate=$_REQUEST['startDate'];
         $endDate=$_REQUEST['endDate'];
 

         $con->query("insert into doctorexpierence values ('','$hosName','$startDate','$endDate','$profile_id')");




       }
       if (isset($_REQUEST['exp_id'])){

           $exp_id=$_REQUEST['exp_id'];
           $hospitalName=$_REQUEST['hospital'];
           $start=$_REQUEST['start'];
           $end=$_REQUEST['end'];


           for ($i=0;$i<sizeof($exp_id);$i++){
               $doc_exp_id=$exp_id[$i];
               $name=$hospitalName[$i];
               $startDate=$start[$i];
               $endDate=$end[$i];

               $con->query("update doctorexpierence set hospitalName='$name',startFrom='$startDate',endDate='$endDate' where doc_exp_id='$doc_exp_id'");

           }
       }
       if (isset($_REQUEST['addNewExpierence'])){
           $hosName=$_REQUEST['hospitalName'];
           $startDate=$_REQUEST['docStart'];
           $endDate=$_REQUEST['docEnd'];

           for($i=0;$i<sizeof($hosName);$i++){
               $con->query("insert into doctorexpierence values ('','$hosName[$i]','$startDate[$i]','$endDate[$i]','$profile_id')");
           }

       }

        header("location:doctor-profile-setting.php");
        return;
    }

?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Doctor Profile Setting - Health Guide</title>

    <link href="assets/img/favicon.png" rel="icon">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/plugins/bootstrap-tagsinput/css/bootstrap-tagsinput.css">




    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
<!-- Main Wrapper -->
<div class="main-wrapper">
    <!--Header Part-->
    <header class="header">
        <nav class="navbar navbar-expand-lg header-nav">
            <!---Logo-->
            <div class="navbar-header">
                <a href="index.php" class="navbar-brand logo"><img src="assets/img/log.png" class="img-fluid" alt="Logo"></a>
            </div>
            <ul class="nav header-navbar-rht">
                <!-- User Menu -->
                <li class="nav-item dropdown has-arrow logged-item">
                    <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
								<span class="user-img">
									<img class="rounded-circle" src="assets/img/doctors/<?=$doc_image?>" width="31" alt="image">
								</span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right">
                        <div class="user-header">
                            <div class="avatar avatar-sm">
                                <img src="assets/img/doctors/<?=$doc_image?>" alt="User Image" class="avatar-img rounded-circle">
                            </div>
                            <div class="user-text">
                                <h6><?php echo $doctorRecordRow['doc_firstName'];  ?></h6>
                                <p class="text-muted mb-0">Doctor</p>
                            </div>
                        </div>
                        <a class="dropdown-item" href="doctor-dashboard.php">Dashboard</a>
                        <a class="dropdown-item" href="doctor-profile-setting.php">Profile Settings</a>
                        <a class="dropdown-item" href="login.php">Logout</a>
                    </div>
                </li>
                <!-- /User Menu -->

            </ul>
        </nav>


    </header>
    <!--/Header-->


    <!---Page Content-->
    <div class="content">
        <div class="container-fluid">
            <div class="row">

                <div class="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
                    <!-- Dashboard Sidebar -->
                    <div class="profile-sidebar">
                        <div class="widget-profile pro-widget-content">
                            <div class="profile-info-widget">
                                <a href="#" class="booking-doc-img">
                                    <img src="assets/img/doctors/<?=$doc_image?>" alt="Doctor Image">
                                </a>
                                <div class="profile-det-info">
                                    <h3>Dr. <?php echo $doctorRecordRow['doc_firstName']." ".$doctorRecordRow['doc_lastName']; ?> </h3>

                                    <div class="patient-details">
                                        <h5 class="mb-0"><?php
                                              echo $doctorRecordRow['doc_specialization'];
                                            ?></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="dashboard-widget">
                            <nav class="dashboard-menu">
                                <ul>
                                    <li id="dashTab">
                                        <a href="doctor-dashboard.php">
                                            <i class="fas fa-columns"></i>
                                            <span>Dashboard</span>
                                        </a>
                                    </li>
                                    <li >
                                        <a href="#" onclick="appointmentDashboard();">
                                            <i class="fas fa-calendar-check"></i>
                                            <span>Appointments</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" onclick="patientList();">
                                            <i class="fas fa-user-injured"></i>
                                            <span>My Patients</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="schedule-timings.php">
                                            <i class="fas fa-hourglass-start"></i>
                                            <span>Schedule Timings</span>
                                        </a>
                                    </li>

                                    <li id="profile" class="active">
                                        <a class="active" href="doctor-profile-setting.php">
                                            <i class="fas fa-user-cog"></i>
                                            <span>Profile Settings</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" onclick="socialMedia();">
                                            <i class="fas fa-share-alt"></i>
                                            <span>Social Media</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="doctor-change-password.php">
                                            <i class="fas fa-lock"></i>
                                            <span>Change Password</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="delete-doctor-account.php">
                                            <i class="fas fa-trash"></i>
                                            <span>Delete Account</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="index.php">
                                            <i class="fas fa-sign-out-alt"></i>
                                            <span>Logout</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>

                    <!-- /Dashboard Sidebar -->

                    <!---Profile Setting-->
                <div class="col-md-7 col-lg-8 col-xl-9">

                    <div class="row" id="">
                        <div class="col-md-12">
                            <!-- Basic Information -->
                            <div class="card">
                                <form action="doctor-profile-setting.php" method="post" enctype="multipart/form-data">
                                <div class="card-body">
                                    <h4 class="card-title">Basic Information</h4>
                                    <div class="row form-row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <div class="change-avatar">
                                                    <div class="profile-img">
                                                        <img src="assets/img/doctors/<?=$doc_image?>" alt="Doctor Image">
                                                    </div>
                                                    <div class="upload-img">
                                                        <div class="change-photo-btn">
                                                            <span><i class="fa fa-upload"></i> Upload Photo</span>
                                                            <input  type="file" accept="image/*" class="upload" name="doc_image">
                                                        </div>
                                                        <small class="form-text text-muted">Allowed JPG, GIF or PNG. Max size of 2MB</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>First Name </label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_firstName']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Last Name </label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_lastName']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Specialization </label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_specialization']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Province </label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_province']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>District</label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_district']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Location</label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_location']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Email / Username</label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_email']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Qualification</label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_qualification']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>University</label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_university']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Contact</label>
                                                <input type="text" name="contact" value="<?php echo $doctorRecordRow['doc_contact']; ?> " class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Birth</label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_birth']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Status</label>
                                                <input type="text" value="<?php echo $doctorRecordRow['doc_status']; ?> " class="form-control" readonly>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Gender</label>
                                                <select class="form-control" readonly>
                                                    <option >Select</option>
                                                    <option <?php if ($doctorRecordRow['doc_gender']=='Male'){ echo "selected"; }  ?> >Male</option>
                                                    <option <?php if ($doctorRecordRow['doc_gender']=='Female'){ echo "selected"; }  ?> >Female</option>
                                                </select>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="mt-2 float-md-right float-sm-left">
                                        <button cla type="submit" name="upload"  class="btn btn-primary submit-btn">Save Changes</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                            <!-- /Basic Information -->

                            <!-- About Me -->
                            <div class="card">
                                <form action="doctor-profile-setting.php" method="get">
                                <div class="card-body">
                                    <h4 class="card-title">About Me</h4>
                                    <div class="form-group mb-0">
                                        <label>Biography</label>
                                        <textarea class="form-control" name="biography" rows="7"><?php echo $pro_des['profile_biography']; ?></textarea>



                                </div>
                                    <div class="border-top mt-3"></div>

                                    <div class="mt-4">
                                        <!-- Cotact Details   -->
                                        <h4 class="card-title">Contact Details</h4>
                                        <div class="row form-row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Contact </label>
                                                    <input type="text" name="addressLine" value="<?php echo $pro_des['contact']; ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">City</label>
                                                    <input type="text" name="city" value="<?php echo $pro_des['profile_city']; ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="control-label">State / Province</label>
                                                    <input type="text" name="province" value="<?php echo $pro_des['profile_province']; ?>" class="form-control">
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                        <!-- /Cotact Details   -->
                                    <div class="border-top mt-3"></div>
                                        <!--- Pricing  --->
                                        <div class="mt-4">
                                            <h4 class="card-title">Fees</h4>

                                            <div class="form-group mb-0">
                                                <div id="pricing_select">

                                                    <div class="custom-control custom-radio custom-control-inline">
                                                        <input type="radio" id="price_custom" name="rating_option" value="custom_price" class="custom-control-input">
                                                        <label class="custom-control-label" for="price_custom">Adding Fees</label>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="row custom_price_cont" id="custom_price_cont" style="display: none;">
                                                <div class="col-md-4">
                                                    <input type="number" class="form-control" id="custom_rating_input" value="<?php echo $pro_des['profile_fees']; ?>" name="fees">
                                                    <small class="form-text text-muted">Enter your fees amount in AFG</small>
                                                </div>
                                            </div>

                                        </div>

                                        <!--- /Pricing --->
                                    <div class="border-top mt-3"></div>
                                        <!--- Services and Specialization ---->
                                        <div class="mt-4">
                                            <h4 class="card-title">Services and Specialization</h4>
                                            <div class="form-group">
                                                <label>Services</label>
                                                <input type="text" data-role="tagsinput" class="input-tags form-control" value="<?php echo $pro_des['profile_services']; ?>" placeholder="Enter Services" name="services">
                                                <small class="form-text text-muted">Note : Type & Press enter to add new services</small>
                                            </div>
                                            <div class="form-group mb-0">
                                                <label>Specialization </label>
                                                <input class="input-tags form-control" type="text" data-role="tagsinput" placeholder="Enter Specialization" value="<?php echo $pro_des['profile_specilizations']; ?>" name="specializations"  id="specialist">
                                                <small class="form-text text-muted">Note : Type & Press  enter to add new specialization</small>
                                            </div>
                                        </div>

                                        <!--- /Services and Specializations --->
                                    <div class="mt-2 float-md-right float-sm-left">
                                        <button cla type="submit" name="saveme"  class="btn btn-primary submit-btn">Save Changes</button>
                                    </div>
                                     </div>
                                </form>
                            </div>
                            <!-- /About Me -->


                            <!-- Clinic Info -->

                            <div class="card">
                                <form action="doctor-profile-setting.php" method="get">
                                <div class="card-body">
                                    <h4 class="card-title">Clinic Details</h4>

                                    <div class="clinic-info">
                                        <?php
                                        while($row=$doc_clinics->fetch_array()) {

                                            ?>
                                            <div class="row form-row clinic-cont">
                                                <div class="col-12 col-md-10 col-lg-11">

                                                    <div class="row form-row">
                                                        <div class="col-12 col-md-6 col-lg-6">
                                                            <div class="form-group">
                                                                <label>Clinic Name</label>
                                                                <input type="hidden" name="clinicID[]" value="<?=$row['doc_clinic_id'] ?>">
                                                                <input type="text" name="clinicName[]"
                                                                  value="<?=$row['clinic_name']?>"     class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6 col-lg-6">
                                                            <div class="form-group">
                                                                <label>Clinic Address</label>
                                                                <input type="text" name="clinicAddress[]"
                                                                    value="<?=$row['clinic_address']?>"   class="form-control">
                                                                <input type="hidden" name="profileID" value="<?=$row['profile_id']?>">
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>


                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <div class="add-more">
                                        <small class="form-text text-muted d-none mb-1 cliCounter">Sorry, you are not allowed to enter more than four clinic details</small>
                                        <a href="" class="add-clinic"><i class="fa fa-plus-circle"></i> Add More</a>


                                    </div>
                                    <div class="mt-2 float-md-right float-sm-left">
                                        <button cla type="submit" name="saveclinicdetails"  class="btn btn-primary submit-btn">Save Changes</button>
                                    </div>
                                </div>
                                    </form>
                            </div>


                            <!-- /Clinic Info -->


                            <!-- Education -->
                            <div class="card">
                                <form action="doctor-profile-setting.php" method="get">
                                <div class="card-body">
                                    <h4 class="card-title">Education</h4>
                                    <div class="education-info">
                                        <?php
                                        while($row=$doc_education->fetch_array()) {

                                            ?>

                                            <div class="row form-row education-cont">
                                                <div class="col-12 col-md-10 col-lg-11">
                                                    <div class="row form-row">
                                                        <div class="col-12 col-md-6 col-lg-4">
                                                            <div class="form-group">
                                                                <label>Degree</label>
                                                                <input type="hidden" name="edu_id[]" value="<?=$row['doc_edu_id']?>">
                                                                <input type="text" name="doctorDegree[]" value="<?=$row['degree']?>" class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6 col-lg-4">
                                                            <div class="form-group">
                                                                <label>College/Institute</label>
                                                                <input type="text" name="doctorCollege[]" value="<?=$row['college']?>" class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6 col-lg-4">
                                                            <div class="form-group">
                                                                <label>Year of Completion</label>
                                                                <input type="number" name="doctorCompletion[]"
                                                                       value="<?=$row['yearofcompletion']?>"      class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>

                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <div class="add-more">
                                        <small class="form-text text-muted d-none mb-1 eduCounter">Sorry, you are not allowed to enter more than four degrees</small>
                                        <a href="" class="add-education"><i class="fa fa-plus-circle"></i> Add More</a>
                                    </div>
                                    <div class="mt-2 float-md-right float-sm-left">
                                        <button  type="submit" name="savedoceducation"  class="btn btn-primary submit-btn">Save Changes</button>
                                    </div>

                                </div>
                                </form>
                            </div>
                            <!-- /Education -->

                            <!-- Experience -->
                            <div class="card">
                                <form action="doctor-profile-setting.php" method="get">
                                <div class="card-body">
                                    <h4 class="card-title">Experience</h4>
                                    <div class="experience-info">
                                        <?php
                                        while($row=$doc_experience->fetch_array()) {


                                            ?>
                                            <div class="row form-row experience-cont">
                                                <div class="col-12 col-md-10 col-lg-11">
                                                    <div class="row form-row">
                                                        <div class="col-12 col-md-6 col-lg-4">
                                                            <div class="form-group">
                                                                <label>Hospital Name</label>
                                                                <input type="hidden" name="exp_id[]" value="<?=$row['doc_exp_id']?>">
                                                                <input type="text" name="hospital[]"
                                                                     value="<?=$row['hospitalName']?>"  class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6 col-lg-4">
                                                            <div class="form-group">
                                                                <label>From</label>
                                                                <input type="date" name="start[]"  value="<?=$row['startFrom']?>" class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6 col-lg-4">
                                                            <div class="form-group">
                                                                <label>To</label>
                                                                <input type="date"  value="<?=$row['endDate']?>" name="end[]" class="form-control">
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>

                                            </div>

                                            <?php
                                        }
                                        ?>
                                    </div>
                                    <div class="add-more">
                                        <small class="form-text text-muted d-none mb-1 hosCounter">Sorry, you are not allowed to enter more than three experience skills</small>
                                        <a href="#" class="add-experience"><i class="fa fa-plus-circle"></i> Add More</a>
                                    </div>
                                    <div class="mt-2 float-md-right float-sm-left">
                                        <button  type="submit" name="savedocexperience"  class="btn btn-primary submit-btn">Save Changes</button>
                                    </div>

                                </div>
                                </form>
                            </div>
                            <!-- /Experience -->


                        </div>
                    </div>

                </div>
                    <!--/Profile Setting-->


            </div>
        </div>
    </div>






</div>
<!-- /Main Wrapper -->

<!-- jQuery -->
<script src="assets/js/jquery.min.js"></script>

<!-- Bootstrap Core JS -->
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>





<!-- Custom JS -->
<script src="assets/js/script.js"></script>
<script src="assets/js/script2.js"></script>

<!-- Bootstrap Tagsinput JS -->
<script src="assets/plugins/bootstrap-tagsinput/js/bootstrap-tagsinput.js"></script>

<!-- Profile Settings JS -->
<script src="assets/js/profile-setting.js"></script>





</body>
</html>



