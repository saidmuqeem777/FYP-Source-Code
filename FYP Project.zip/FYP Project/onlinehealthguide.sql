-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2020 at 08:03 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinehealthguide`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(128) NOT NULL,
  `time` varchar(128) DEFAULT NULL,
  `date` varchar(128) DEFAULT NULL,
  `user_id` int(128) DEFAULT NULL,
  `doc_user_id` int(128) DEFAULT NULL,
  `visitor_id` int(128) DEFAULT NULL,
  `status` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `time`, `date`, `user_id`, `doc_user_id`, `visitor_id`, `status`) VALUES
(1, '06:00 AM-11:00 AM', '15 Aug 2020', 14, 2, NULL, 'unapproved'),
(2, '03:00 AM-05:00 AM', '15 Aug 2020', 15, 2, NULL, 'unapproved'),
(3, '03:00 AM-05:00 AM', '15 Aug 2020', 16, 2, NULL, 'unapproved'),
(5, '03:00 AM-05:00 AM', '22 Aug 2020', NULL, 2, 4, 'unapproved'),
(6, '003:48 PM:00 AM-004:03 PM:00 AM', '22 Aug 2020', 14, 2, NULL, 'unapproved'),
(10, '09:53 PM-10:08 PM', '22 Aug 2020', 14, 2, NULL, 'unapproved'),
(11, '03:48 PM-04:03 PM', '22 Aug 2020', NULL, 2, 5, 'unapproved'),
(12, '06:54 PM-07:09 PM', '16 Aug 2020', NULL, 2, 6, 'approved'),
(13, '06:54 PM-07:09 PM', '16 Aug 2020', NULL, 2, 7, 'unapproved'),
(14, '04:00 PM-05:00 PM', '22 Aug 2020', 14, 2, NULL, 'unapproved'),
(15, '03:48 PM-04:03 PM', '16 Aug 2020', NULL, 2, 8, 'unapproved'),
(16, '08:56 PM-09:11 PM', '18 Aug 2020', NULL, 2, 9, 'unapproved'),
(17, '11:46 AM-12:01 PM', '17 Aug 2020', NULL, 2, 10, 'unapproved'),
(18, '002:21 AM-02:36 AM', '22 Aug 2020', NULL, 18, 12, 'unapproved');

-- --------------------------------------------------------

--
-- Table structure for table `chat_message`
--

CREATE TABLE `chat_message` (
  `id` int(128) NOT NULL,
  `to_user_id` int(128) DEFAULT NULL,
  `from_user_id` int(128) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_message`
--

INSERT INTO `chat_message` (`id`, `to_user_id`, `from_user_id`, `message`, `timestamp`, `status`) VALUES
(1, 2, 2, 'Hi i amsa  ', '2020-08-16 05:55:14', 'seen'),
(2, 14, 2, 'Hi i am a doctor where you can met', '2020-08-16 06:17:10', 'seen'),
(3, 2, 14, 'ok we will met', '2020-08-16 06:18:34', 'seen'),
(4, 14, 2, 'just wait a minute', '2020-08-16 06:19:52', 'seen'),
(5, 14, 2, 'Sweet one bro', '2020-08-16 06:29:43', 'seen'),
(6, 2, 14, 'ok ooo', '2020-08-16 06:31:41', 'seen'),
(7, 2, 14, 'Ok sir', '2020-08-16 12:37:52', 'seen'),
(8, 2, 14, 'Hi we need you', '2020-08-16 18:00:56', 'seen'),
(9, 2, 14, 'Gone good for us', '2020-08-16 18:00:56', 'seen'),
(10, 3, 14, 'Me working with you', '2020-08-16 18:00:56', 'seen'),
(11, 2, 14, 'Hi jee ', '2020-08-16 18:05:40', 'seen'),
(12, 2, 14, 'Zendabad', '2020-08-16 05:43:45', 'not seen');

-- --------------------------------------------------------

--
-- Table structure for table `clinics`
--

CREATE TABLE `clinics` (
  `clinic_id` int(128) NOT NULL,
  `clinic_name` varchar(128) DEFAULT NULL,
  `clinic_type` varchar(128) DEFAULT NULL,
  `clinic_location` varchar(128) DEFAULT NULL,
  `clinic_status` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinics`
--

INSERT INTO `clinics` (`clinic_id`, `clinic_name`, `clinic_type`, `clinic_location`, `clinic_status`) VALUES
(1, 'New Wajid', 'Eye', 'kabul', 'approved'),
(2, 'New Muqeem', 'Dentist', 'Nangarhar', 'approved'),
(3, 'New Zwand', 'Dermatologist', 'Paktia', 'approved'),
(4, 'Mong Yoo', 'Primary Care', 'Ghazni', 'approved'),
(5, 'Taso Se Kawia', 'Skin', 'kabul', 'approved'),
(6, 'Taso Se', 'Skin', 'kabul', 'approved'),
(7, 'Zeeshan', 'Skin', 'Balkh', 'approved'),
(8, 'New Raheem', 'Dermatologist', 'kabul', 'approved'),
(9, 'Kela Kega Ma', 'Eye', 'kabul', 'approved'),
(10, 'Zaman New', 'Skin', 'kabul', 'approved'),
(11, 'New Halimi', 'Eye', '01 Block,Panjab,Bamyan', 'Approved'),
(12, 'Jawad', 'Dentist', '04 Block,Guzara,Herat', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doc_id` int(128) NOT NULL,
  `doc_firstName` varchar(128) DEFAULT NULL,
  `doc_lastName` varchar(128) DEFAULT NULL,
  `doc_specialization` varchar(128) DEFAULT NULL,
  `doc_province` varchar(128) DEFAULT NULL,
  `doc_district` varchar(128) DEFAULT NULL,
  `doc_location` varchar(128) DEFAULT NULL,
  `doc_email` varchar(128) DEFAULT NULL,
  `doc_qualification` varchar(128) DEFAULT NULL,
  `doc_university` varchar(128) DEFAULT NULL,
  `doc_contact` varchar(128) DEFAULT NULL,
  `doc_gender` varchar(128) DEFAULT NULL,
  `doc_birth` varchar(128) DEFAULT NULL,
  `doc_status` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doc_id`, `doc_firstName`, `doc_lastName`, `doc_specialization`, `doc_province`, `doc_district`, `doc_location`, `doc_email`, `doc_qualification`, `doc_university`, `doc_contact`, `doc_gender`, `doc_birth`, `doc_status`) VALUES
(1, 'Said Muqeem', 'Haashimi', 'Dentist', 'Paktia', 'Chamkani', '02 Block,Behsood,Nangarhar', 'saidmuqeem@gmail.com', 'MBBS', 'Rokhan University', '0766229510', 'Male', '2020-08-18', 'Approved'),
(2, 'Khalid Khan', 'Saifi', 'Eye', 'Kabul', 'Kabul', '02 Block, Kabul, Kabul', 'khalidkhan@gmail.com', 'MD', 'Kardan University', '0766229510', 'Male', NULL, 'approved'),
(3, 'Samim ', 'Saifi', 'Primary Care', 'Konar', 'Asadabad', 'Nangarhar', 'samimsaifi@gmail.com', 'MD', 'Kardan University', '0766229510', 'Male', NULL, 'approved'),
(4, 'Zwan ', 'Ahamd', 'Skin', 'Konar', 'Asadabad', 'Nangarhar', 'zwanahmad@gmail.com', 'MD', 'Kardan University', '0766229510', 'Male', NULL, 'approved'),
(5, 'Karim ', 'Ahamd', 'Eye', 'Konar', 'Asadabad', 'Kabul', 'karimahmad@gmail.com', 'MBBS', 'Rokhan University', '0766229510', 'Male', NULL, 'approved'),
(6, 'Bushra ', 'Bibi', 'Skin', 'Kabul', 'Kabul', 'Kabul', 'bushrabibi@gmail.com', 'MD', 'Rokhan University', '0766229510', 'Female', NULL, 'approved'),
(7, 'Naeem ', 'Ahmad', 'Urology', 'Ghazni', 'Ghazni', 'Ghazni', 'naeemahmad@gmail.com', 'MD', 'Rokhan University', '0766229510', 'Male', NULL, 'approved'),
(8, 'Gul Panra ', 'Zwana', 'Skin', 'Ghazni', 'Ghazni', 'Ghazni', 'gulpanra@gmail.com', 'MD', 'Rokhan University', '0766229510', 'Female', NULL, 'approved'),
(9, 'Shiasta', 'Gula', 'Skin', 'Ghazni', 'Ghazni', 'Ghazni', 'shiastagula@gmail.com', 'MD', 'Rokhan University', '0766229510', 'Female', NULL, 'approved'),
(10, 'Saman', 'Ahmad', 'Eye', 'Paktia', 'Chamkani', 'Ghazni', 'samanahmad@gmail.com', 'MD', 'Rokhan University', '0766229510', 'Female', NULL, 'approved'),
(11, 'Ahamd Agha', 'Halimi', 'Skin', 'Paktia', 'Chamkani', 'Kabul', 'saidmuqeemhashimi@gmail.com', 'MBBS', 'Rokhan University', '0766229510', 'Male', NULL, 'approved'),
(12, 'Said Muqeemmmmmmmmmmmmmmmmmmmmmmmmmmmmmm', 'Mad', 'Neurology', 'Nangarhar', 'Achin', 'Paktia,Jalalabad,abc', 'muqeemhalimi@gmail.com', 'MBBS', 'Spin Ghar University', '0766888123', 'Female', '20200-08-13', 'Approved'),
(13, 'Ahmad Fareed', 'Hashimi', 'Dentist', 'Nangarhar', 'Achin', '02 Block,Batikot,Nangarhar', 'ahmadfareed@gmail.com', 'MD', 'Kardan University', '0799009487', 'Male', '2020-08-12', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `doctorclinics`
--

CREATE TABLE `doctorclinics` (
  `doc_clinic_id` int(128) NOT NULL,
  `clinic_name` varchar(128) DEFAULT NULL,
  `clinic_address` varchar(128) DEFAULT NULL,
  `profile_id` int(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorclinics`
--

INSERT INTO `doctorclinics` (`doc_clinic_id`, `clinic_name`, `clinic_address`, `profile_id`) VALUES
(1, 'Muqeem Clinic', 'Kabul', 1),
(2, 'Ahmad Clinic', 'Nangarhar', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctoreducation`
--

CREATE TABLE `doctoreducation` (
  `doc_edu_id` int(128) NOT NULL,
  `degree` varchar(128) DEFAULT NULL,
  `college` varchar(128) DEFAULT NULL,
  `yearofcompletion` varchar(128) DEFAULT NULL,
  `profile_id` int(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctorexpierence`
--

CREATE TABLE `doctorexpierence` (
  `doc_exp_id` int(128) NOT NULL,
  `hospitalName` varchar(128) DEFAULT NULL,
  `startFrom` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `profile_id` int(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctorprofile`
--

CREATE TABLE `doctorprofile` (
  `profile_id` int(128) NOT NULL,
  `profile_biography` varchar(600) DEFAULT NULL,
  `contact` varchar(128) DEFAULT NULL,
  `profile_city` varchar(128) DEFAULT NULL,
  `profile_province` varchar(128) DEFAULT NULL,
  `profile_fees` int(128) DEFAULT NULL,
  `profile_services` varchar(128) DEFAULT NULL,
  `profile_specilizations` varchar(128) DEFAULT NULL,
  `user_id` int(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorprofile`
--

INSERT INTO `doctorprofile` (`profile_id`, `profile_biography`, `contact`, `profile_city`, `profile_province`, `profile_fees`, `profile_services`, `profile_specilizations`, `user_id`) VALUES
(1, 'df dsfjk fj dskjf skjf kjs fkjsd fkjsd fkjsd fkj sdkj sdkjf sdjf kjf dkjsf skjd fkjsd fkjsdd kjds kjsd fkjds fkjsd fkjs dfjk sdkjf sdkjf sdkjdf sdkjdf sdkjf sdkjf skjddf jksd fkjsd fkjsd fkjsd fdsjk fkjds fkjds fdskj fkjsd fkjdsf sdjk fjksd fkjsdf jksd fjksd fjksd fjksd fkjsd fkjds fkjs djkf dskjf sdkjf sdkj fkjds fskjd fkjds fkjsd fsdkjf sdkj fksjd fjskdd fkjae fkjsd fjk skjf ewjk fjek', '0766229510', 'Select', 'Laghman', 1200, '', '', 2),
(2, 'wejkrwe rrjew rjwe rjew kjr wejkr wejr wekjr jkwe rjkwe djk wejd wje djwe djkw edj wejd ewj dwje djekw djwe djkew djwe djwe djkwe djkwe djwe djkwe djw djkwe djkwe djwe djwe djwe djwe djew dje djkw edj wejd wejk djwe djwe jwe fj wejf wej djew djwe dj wejd wejd wejd wej dwje djew djew djwe djwk jd ewj dwkedkwedkwekdwekdwedwewe.', '0766229510', 'Select', 'Peshawar', 1500, 'Eye Check,Eye See', '', 18);

-- --------------------------------------------------------

--
-- Table structure for table `doctorslots`
--

CREATE TABLE `doctorslots` (
  `user_id` int(128) DEFAULT NULL,
  `start_time` varchar(128) DEFAULT NULL,
  `end_time` varchar(128) DEFAULT NULL,
  `saturday` varchar(128) DEFAULT NULL,
  `sunday` varchar(128) DEFAULT NULL,
  `monday` varchar(128) DEFAULT NULL,
  `tuesday` varchar(128) DEFAULT NULL,
  `wednesday` varchar(128) DEFAULT NULL,
  `thursday` varchar(128) DEFAULT NULL,
  `friday` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslots`
--

INSERT INTO `doctorslots` (`user_id`, `start_time`, `end_time`, `saturday`, `sunday`, `monday`, `tuesday`, `wednesday`, `thursday`, `friday`) VALUES
(1, '20', '22', 'yes', NULL, NULL, NULL, NULL, NULL, NULL),
(3, '10', '20', NULL, NULL, NULL, 'yes', NULL, NULL, NULL),
(4, '12', '22', NULL, NULL, NULL, NULL, 'yes', NULL, NULL),
(5, '17', '21', NULL, 'yes', NULL, NULL, NULL, NULL, NULL),
(6, '14', '21', NULL, NULL, NULL, NULL, NULL, 'yes', NULL),
(7, '13', '20', NULL, 'yes', NULL, NULL, NULL, NULL, NULL),
(8, '17', '22', NULL, 'yes', NULL, NULL, NULL, NULL, NULL),
(9, '18', '22', 'yes', NULL, NULL, NULL, NULL, NULL, NULL),
(2, '03:48 PM', '04:03 PM', NULL, 'yes', NULL, NULL, NULL, NULL, NULL),
(2, '06:54 PM', '07:09 PM', NULL, 'yes', NULL, NULL, NULL, NULL, NULL),
(2, '08:56 PM', '09:11 PM', NULL, NULL, NULL, 'yes', NULL, NULL, NULL),
(2, '04:54 PM', '05:09 PM', NULL, NULL, NULL, NULL, 'yes', NULL, NULL),
(2, '008:54 AM', '09:09 AM', NULL, NULL, NULL, NULL, NULL, 'yes', NULL),
(2, '09:53 PM', '10:08 PM', 'yes', NULL, NULL, NULL, NULL, NULL, NULL),
(2, '11:45 AM', '12:00 PM', NULL, NULL, NULL, NULL, NULL, 'yes', NULL),
(2, '06:10 PM', '06:40 PM', 'yes', NULL, NULL, NULL, NULL, NULL, NULL),
(2, '06:15 PM', '07:00 PM', 'yes', NULL, NULL, NULL, NULL, NULL, NULL),
(2, '04:00 PM', '05:00 PM', 'yes', NULL, NULL, NULL, NULL, NULL, NULL),
(2, '11:46 AM', '12:01 PM', NULL, NULL, 'yes', NULL, NULL, NULL, NULL),
(18, '002:21 AM', '02:36 AM', 'yes', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hos_id` int(128) NOT NULL,
  `hos_name` varchar(128) DEFAULT NULL,
  `hos_numOfDept` int(128) DEFAULT NULL,
  `hos_numOfDoctors` int(128) DEFAULT NULL,
  `hos_deptDesc` varchar(128) DEFAULT NULL,
  `hos_location` varchar(128) DEFAULT NULL,
  `hos_status` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hos_id`, `hos_name`, `hos_numOfDept`, `hos_numOfDoctors`, `hos_deptDesc`, `hos_location`, `hos_status`) VALUES
(1, 'Al Shafa', 34, 50, 'Eye,Dentist,Skin', '04 Block,Herat,Herat', 'Approved'),
(2, 'New Kabul', 45, 34, 'Eye,Dentist,Skin,Dermatologist', '09 Block,Achin,Nangarhar', 'Approved'),
(3, 'Zwan Nangarhar', 34, 50, 'Eye,Dentist,Dermatologist', 'Nangarhar', 'approved'),
(4, 'New Zwandoon', 45, 34, 'Eye,Dentist,Skin,Dermatologist', 'Kabul', 'approved'),
(5, 'Tezan ', 34, 50, 'Eye,Dentist,Skin,Primar Care', 'Paktia', 'approved'),
(6, 'New Khalas', 45, 34, 'Eye,Dentist,Skin', '02 Block,Gelan,Ghazni', 'Approved'),
(7, 'New Family Care', 34, 50, 'Eye,Dentist,Skin,Primar Care,Urology', 'Konar', 'approved'),
(8, 'New Healthcare', 45, 34, 'Eye,Dentist,Skin', 'Kabul', 'approved'),
(9, 'New Zwand Care', 34, 50, 'Eye,Dentist,Skin,Primar Care,Urology', 'Konar', 'approved'),
(10, 'New Khwakha', 45, 34, 'Eye,Dentist,Skin', 'Kabul', 'approved'),
(11, 'New Muqeem Khan', 34, 34, 'Eye,Dentist', '02 Block,Bagrami,Kabul', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `medicals`
--

CREATE TABLE `medicals` (
  `medical_id` int(128) NOT NULL,
  `medical_name` varchar(128) DEFAULT NULL,
  `medical_location` varchar(128) DEFAULT NULL,
  `medical_status` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicals`
--

INSERT INTO `medicals` (`medical_id`, `medical_name`, `medical_location`, `medical_status`) VALUES
(2, 'Al Zeeshan', 'Nangarhar', 'approved'),
(3, 'Al Saifi', 'Konar', 'approved'),
(4, 'New Zwan', 'Paktia', 'approved'),
(5, 'jan Agha', 'Balkh', 'approved'),
(6, 'New Kabul', 'Kabul', 'approved'),
(7, 'New Zwan', 'Kabul', 'approved'),
(8, 'New Jan Agha', '03 Block,Dahbala,Nangarhar', 'Approved'),
(9, 'Hashimi Life', '02 Block,Guzara,Herat', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `medicineindustry`
--

CREATE TABLE `medicineindustry` (
  `medicine_id` int(128) NOT NULL,
  `medicine_name` varchar(128) DEFAULT NULL,
  `company_name` varchar(128) DEFAULT NULL,
  `medicine_status` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `outsidedoctor`
--

CREATE TABLE `outsidedoctor` (
  `id` int(128) NOT NULL,
  `firstname` varchar(128) DEFAULT NULL,
  `lastname` varchar(128) DEFAULT NULL,
  `specialization` varchar(128) DEFAULT NULL,
  `country` varchar(128) DEFAULT NULL,
  `location` varchar(128) DEFAULT NULL,
  `contact` varchar(128) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `gender` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `outsidedoctor`
--

INSERT INTO `outsidedoctor` (`id`, `firstname`, `lastname`, `specialization`, `country`, `location`, `contact`, `email`, `gender`) VALUES
(1, 'Zaman', 'Khan Jan', 'Eye', 'Pakistan', 'Phase 4,Dabgar e garden,Peshawar', '00923168797035', 'zamankhan@gmail.com', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `pictures`
--

CREATE TABLE `pictures` (
  `id` int(128) NOT NULL,
  `file_name` varchar(128) DEFAULT NULL,
  `user_id` int(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pictures`
--

INSERT INTO `pictures` (`id`, `file_name`, `user_id`) VALUES
(1, '1597483176.jpg', 1),
(2, '1597483306.jpg', 2),
(3, '1597483340.jpg', 3),
(4, '1597483390.jpg', 4),
(5, '1597483440.jpg', 5),
(6, '1597483477.jpg', 6),
(7, '1597483513.jpg', 7),
(8, '1597483544.jpg', 8),
(9, '1597483579.jpg', 9),
(10, '1597484809.jpg', 14),
(11, '1597553696.jpg', 13),
(12, '1597699033.jpg', 18);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_d` int(128) NOT NULL,
  `profile_id` int(128) DEFAULT NULL,
  `reviewer_id` int(128) DEFAULT NULL,
  `reviewer_msg` mediumtext NOT NULL,
  `review_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rating` int(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`review_d`, `profile_id`, `reviewer_id`, `reviewer_msg`, `review_date`, `rating`) VALUES
(1, 2, 14, 'It is very good docotr', '0000-00-00 00:00:00', 2),
(2, 2, 14, 'This is a good doctor', '0000-00-00 00:00:00', 4),
(3, 2, 14, 'This is a bad doctor', '2020-08-18 02:59:12', 3),
(4, 2, 14, 'Very helpful doctor', '2020-08-18 03:34:25', 5),
(5, 1, 14, 'Good Doctor', '2020-08-18 03:43:24', 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(128) NOT NULL,
  `user_name` varchar(128) DEFAULT NULL,
  `user_username` varchar(128) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_address` varchar(128) DEFAULT NULL,
  `user_contact` varchar(128) DEFAULT NULL,
  `user_type` varchar(128) DEFAULT NULL,
  `user_status` varchar(128) DEFAULT NULL,
  `doc_id` int(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_username`, `user_password`, `user_address`, `user_contact`, `user_type`, `user_status`, `doc_id`) VALUES
(1, 'Said Muqeem', 'saidmuqeem@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Nangarhar', '0766229510', 'doctor', 'approved', 1),
(2, 'Khalid Khan', 'khalidkhan@gmail.com', '$2y$10$ez0XiRAf1FW4X6SDhCjA1eJKkBa4q64NDIKPIomUQ2Ey34wV8DzBS', 'Kabul', '0766229510', 'doctor', 'approved', 2),
(3, 'Samim', 'samimsaifi@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Nangarhar', '0766229510', 'doctor', 'approved', 3),
(4, 'Zwan Ahmad', 'zwanahmad@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Kabul', '0766229510', 'doctor', 'approved', 4),
(5, 'Karim Ahmad', 'karimahmad@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Kabul', '0766229510', 'doctor', 'approved', 5),
(6, 'Bushra Bibi', 'bushrabibi@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Kabul', '0766229510', 'doctor', 'approved', 6),
(7, 'Naeem Ahamd', 'naeemahmad@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Ghazni', '0766229510', 'doctor', 'approved', 7),
(8, 'Gul Panra', 'gulpanra@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Ghazni', '0766229510', 'doctor', 'approved', 8),
(9, 'Shiasta Gula', 'shiastagula@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Ghazni', '0766229510', 'doctor', 'approved', 9),
(11, 'Said Muqeem Halimi', 'muqeem12@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Kabul', '0766229510', 'super admin', 'approved', NULL),
(12, 'Ahamd Agha', 'saidmuqeemhashimi@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Paktia', '0766229510', 'doctor', 'unapproved', 11),
(13, 'jan abc', 'janahmad@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', '', '0766229510', 'moha', 'approved', NULL),
(14, 'Said Jalal', 'saidjalal@gmail.com', '$2y$10$SjEpdkElzsGjBCSsA6Xkn.5ZZRdEDgjC2dNSRn9clH1n5IPWF0SLe', 'Kabul', '0766229510', 'patient', 'approved', NULL),
(15, 'Said Aminullah', 'saidaminullah@gmail.com', '$2y$10$C3/aktWNxlpRE79Z0XYwueiE9qFJJNDmF6DTcKENB4HXxSXpfjPl6', 'Nangarhar', '0766229510', 'patient', 'approved', NULL),
(16, 'Said Muqeem', 'muqeemhalimi@gmail.com', '$2y$10$snTN3gVpQspiVj6QCjW2v.QWzW8qv48fKVSkZ3UdEOTCUnDdMvYJa', 'Kabul', '0766229510', 'patient', 'approved', NULL),
(17, 'Said Manan', 'saidmanan@gmail.com', '$2y$10$j17OBtl8NH8yt59qhxU1ou7aXmr3BzGccFrStrohlw/nAE6FTu5lO', 'Kabul', '0766888123', 'moha', 'approved', NULL),
(18, 'Zaman Khan', 'zamankhan@gmail.com', '$2y$10$ez0XiRAf1FW4X6SDhCjA1eJKkBa4q64NDIKPIomUQ2Ey34wV8DzBS', 'Peshawar', '0766229510', 'doctor', 'approved', NULL),
(19, 'Muqeem Hasini', 'fa16-bse-405@cuilahore.edu.pk', '$2y$10$im2P2eTZayGYEZmkipTmQunrtaE2Q6KHXFCn/Drpxh9crA8nOcdY6', 'Paktia', '0766229510', 'patient', 'unapproved', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(128) NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `age` int(128) DEFAULT NULL,
  `gender` varchar(128) DEFAULT NULL,
  `contact` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `name`, `age`, `gender`, `contact`) VALUES
(1, 'Said Hashimi', 23, 'Male', '076622951'),
(2, 'Said Hashimi', 23, 'Male', '0766229510'),
(3, 'Said Agha34', 34, 'Male', '03168797035'),
(4, 'Said Agha', 34, 'Male', '0766229510'),
(5, 'Muqeem Said ', 23, 'Male', '0766229510'),
(6, 'Muqeem Said', 23, 'Male', '0766229510'),
(7, 'Javid Hashimi', 23, 'Male', '0766229510'),
(8, 'Jan Ahmad', 23, 'Male', '0766229510'),
(9, 'Zaman', 45, 'Male', '0766229510'),
(10, 'Zazi khan', 34, 'Male', '0766229510'),
(11, 'Said Muqeem', 34, 'Select', '0716229510'),
(12, 'Said Muqeem', 34, 'Male', '0766229510');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `doc_user_id` (`doc_user_id`),
  ADD KEY `visitor_id` (`visitor_id`);

--
-- Indexes for table `chat_message`
--
ALTER TABLE `chat_message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `to_user_id` (`to_user_id`),
  ADD KEY `from_user_id` (`from_user_id`);

--
-- Indexes for table `clinics`
--
ALTER TABLE `clinics`
  ADD PRIMARY KEY (`clinic_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doc_id`);

--
-- Indexes for table `doctorclinics`
--
ALTER TABLE `doctorclinics`
  ADD PRIMARY KEY (`doc_clinic_id`),
  ADD KEY `profile_id` (`profile_id`);

--
-- Indexes for table `doctoreducation`
--
ALTER TABLE `doctoreducation`
  ADD PRIMARY KEY (`doc_edu_id`),
  ADD KEY `profile_id` (`profile_id`);

--
-- Indexes for table `doctorexpierence`
--
ALTER TABLE `doctorexpierence`
  ADD PRIMARY KEY (`doc_exp_id`),
  ADD KEY `profile_id` (`profile_id`);

--
-- Indexes for table `doctorprofile`
--
ALTER TABLE `doctorprofile`
  ADD PRIMARY KEY (`profile_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `doctorslots`
--
ALTER TABLE `doctorslots`
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hos_id`);

--
-- Indexes for table `medicals`
--
ALTER TABLE `medicals`
  ADD PRIMARY KEY (`medical_id`);

--
-- Indexes for table `medicineindustry`
--
ALTER TABLE `medicineindustry`
  ADD PRIMARY KEY (`medicine_id`);

--
-- Indexes for table `outsidedoctor`
--
ALTER TABLE `outsidedoctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pictures`
--
ALTER TABLE `pictures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_d`),
  ADD KEY `profile_id` (`profile_id`),
  ADD KEY `reviewer_id` (`reviewer_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `doc_id` (`doc_id`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `chat_message`
--
ALTER TABLE `chat_message`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `clinics`
--
ALTER TABLE `clinics`
  MODIFY `clinic_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doc_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `doctorclinics`
--
ALTER TABLE `doctorclinics`
  MODIFY `doc_clinic_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctoreducation`
--
ALTER TABLE `doctoreducation`
  MODIFY `doc_edu_id` int(128) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctorexpierence`
--
ALTER TABLE `doctorexpierence`
  MODIFY `doc_exp_id` int(128) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctorprofile`
--
ALTER TABLE `doctorprofile`
  MODIFY `profile_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `hos_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `medicals`
--
ALTER TABLE `medicals`
  MODIFY `medical_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `medicineindustry`
--
ALTER TABLE `medicineindustry`
  MODIFY `medicine_id` int(128) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `outsidedoctor`
--
ALTER TABLE `outsidedoctor`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pictures`
--
ALTER TABLE `pictures`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_d` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doc_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`visitor_id`) REFERENCES `visitors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_message`
--
ALTER TABLE `chat_message`
  ADD CONSTRAINT `chat_message_ibfk_1` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_message_ibfk_2` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `doctorclinics`
--
ALTER TABLE `doctorclinics`
  ADD CONSTRAINT `doctorclinics_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `doctorprofile` (`profile_id`) ON DELETE CASCADE;

--
-- Constraints for table `doctoreducation`
--
ALTER TABLE `doctoreducation`
  ADD CONSTRAINT `doctoreducation_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `doctorprofile` (`profile_id`) ON DELETE CASCADE;

--
-- Constraints for table `doctorexpierence`
--
ALTER TABLE `doctorexpierence`
  ADD CONSTRAINT `doctorexpierence_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `doctorprofile` (`profile_id`) ON DELETE CASCADE;

--
-- Constraints for table `doctorprofile`
--
ALTER TABLE `doctorprofile`
  ADD CONSTRAINT `doctorprofile_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `doctorslots`
--
ALTER TABLE `doctorslots`
  ADD CONSTRAINT `doctorslots_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `pictures`
--
ALTER TABLE `pictures`
  ADD CONSTRAINT `pictures_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`doc_id`) REFERENCES `doctor` (`doc_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
